/* sample .h file */

/* include all libraries here */
#include <stdio.h>

/* put any #define statements here */

/* put any structure declarations here */

/* list any needed function prototypes here */
int calcMax( int a, int b );
