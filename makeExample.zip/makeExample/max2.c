/* file:  max2.c  */

/* include the .h header file                         */
/* NOTE: the header file is enclosed in DOUBLE QUOTES */
/*    not angle brackets                              */
#include "max.h"

int calcMax( int a, int b )
{
	if (a > b)
        return a;
      else
        return b;
}
